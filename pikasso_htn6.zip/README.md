# Pikasso

To start frontend, run `npm start`
